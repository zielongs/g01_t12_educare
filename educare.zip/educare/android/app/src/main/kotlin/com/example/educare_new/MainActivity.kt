package com.example.educare_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
