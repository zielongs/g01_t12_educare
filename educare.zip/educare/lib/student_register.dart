/*--------------------------------------------------
Author      : Noraziela Binti Jepsin
Updated by  : Noraziela Binti Jepsin
Tested by   : 
Date        : 28 December 2025
Description :
Student Register Screen for the EduCare App.
- Allows students to create accounts using email and password
- Integrates Firebase Authentication
- Validates input fields
- Restricts email domain to @educare.my and @gmail.com
- Shows loading indicator during registration
- Navigates to login screen after successful registration
--------------------------------------------------*/

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'student_login.dart';

class StudentRegisterScreen extends StatefulWidget {
  const StudentRegisterScreen({super.key});

  @override
  State<StudentRegisterScreen> createState() => _StudentRegisterScreenState();
}

class _StudentRegisterScreenState extends State<StudentRegisterScreen> {
  final _emailController = TextEditingController();
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;
  bool _isObscured = true;

  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void dispose() {
    _emailController.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  //  Email domain validation
  bool _isValidEmailDomain(String email) {
    final lowerEmail = email.toLowerCase();
    return lowerEmail.endsWith('@educare.my') ||
        lowerEmail.endsWith('@gmail.com');
  }

  //  Sign Up method with Firebase
  Future<void> signUpUser() async {
    // Step 1: Validate inputs
    if (_emailController.text.isEmpty) {
      _showSnackBar('Please enter your email address', isError: true);
      return;
    }

    final email = _emailController.text.trim();

    if (!_isValidEmailDomain(email)) {
      _showSnackBar(
        'Please use an @educare.my or @gmail.com email address',
        isError: true,
      );
      return;
    }

    if (_nameController.text.isEmpty) {
      _showSnackBar('Please enter your full name', isError: true);
      return;
    }

    if (_passwordController.text.isEmpty) {
      _showSnackBar('Please create a password', isError: true);
      return;
    }

    if (_passwordController.text.length < 6) {
      _showSnackBar('Password must be at least 6 characters', isError: true);
      return;
    }

    // Step 2: Show loading indicator
    setState(() {
      _isLoading = true;
    });

    try {
      // Step 3: Create user with email + password
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: _passwordController.text.trim(),
      );

      // Step 3.1: Update display name
      await userCredential.user?.updateDisplayName(_nameController.text.trim());

      // Step 4: Success message
      if (mounted) {
        _showSnackBar(
          'Account created successfully! Please login.',
          isError: false,
        );

        // Step 5: Navigate to login screen
        Future.delayed(const Duration(seconds: 1), () {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => const StudentLoginScreen(),
              ),
            );
          }
        });
      }
    } on FirebaseAuthException catch (e) {
      String message;

      switch (e.code) {
        case 'weak-password':
          message = "The password provided is too weak.";
          break;
        case 'email-already-in-use':
          message = "An account already exists for this email.";
          break;
        case 'invalid-email':
          message = "Invalid email format.";
          break;
        case 'network-request-failed':
          message = "Network error. Please check your connection.";
          break;
        default:
          message = e.message ?? "An unknown error occurred.";
      }

      if (mounted) {
        _showSnackBar(message, isError: true);
      }
    } catch (e) {
      if (mounted) {
        _showSnackBar("Error: $e", isError: true);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showSnackBar(String message, {required bool isError}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red[400] : Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF53E1E1), Color(0xFF1A237E)],
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25),
            child: Column(
              children: [
                const SizedBox(height: 50),

                // Back Button
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    icon: const Icon(
                      Icons.arrow_circle_left_outlined,
                      size: 40,
                      color: Colors.white,
                    ),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),

                const Text(
                  'Create an account',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),

                const SizedBox(height: 30),

                _buildInputField(
                  "Email Address",
                  "Enter your email address (@educare.my or @gmail.com)",
                  _emailController,
                ),

                const SizedBox(height: 15),

                _buildInputField(
                  "Full Name",
                  "Enter your full name",
                  _nameController,
                ),

                const SizedBox(height: 15),

                _buildInputField(
                  "Password",
                  "Create your password (min. 6 characters)",
                  _passwordController,
                  isPassword: true,
                ),

                const SizedBox(height: 30),

                ElevatedButton(
                  onPressed: _isLoading ? null : signUpUser,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFA7DED9),
                    minimumSize: const Size(250, 55),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.black),
                        )
                      : const Text(
                          'Create an account',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                ),

                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Already have an account? ",
                      style: TextStyle(color: Colors.white),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const StudentLoginScreen(),
                          ),
                        );
                      },
                      child: const Text(
                        "Login",
                        style: TextStyle(
                          color: Colors.blueAccent,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField(
    String label,
    String hint,
    TextEditingController controller, {
    bool isPassword = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: isPassword ? _isObscured : false,
          keyboardType: isPassword
              ? TextInputType.text
              : (label == "Email Address"
                  ? TextInputType.emailAddress
                  : TextInputType.name),
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Colors.white,
            suffixIcon: isPassword
                ? IconButton(
                    icon: Icon(
                      _isObscured
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                    ),
                    onPressed: () {
                      setState(() {
                        _isObscured = !_isObscured;
                      });
                    },
                  )
                : null,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }
}
