/*--------------------------------------------------
Author      : Noraziela Binti Jepsin
Updated by  : Amir Lukman, Noraziela Binti Jepsin
Tested by   : Amir Lukman
Date        : 28 December 2026
Description : 
Student Menu Screen for the EduCare App.
- Updated navigation routes to match final project structure
- Added logout confirmation dialog
- Integrated Firebase sign out
--------------------------------------------------*/

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StudentMenuScreen extends StatelessWidget {
  const StudentMenuScreen({super.key});

  // ✅ Logout confirmation dialog
  Future<void> _showLogoutDialog(BuildContext context) async {
    return showDialog(
      context: context,
      barrierDismissible: false, // User must tap a button
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Row(
            children: [
              Icon(Icons.logout, color: Colors.red, size: 28),
              SizedBox(width: 10),
              Text('Logout'),
            ],
          ),
          content: const Text(
            'Are you sure you want to logout?',
            style: TextStyle(fontSize: 16),
          ),
          actions: [
            // Cancel button
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            // Logout button
            ElevatedButton(
              onPressed: () async {
                Navigator.of(context).pop(); // Close dialog
                await _performLogout(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'Logout',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ✅ Perform logout with Firebase
  Future<void> _performLogout(BuildContext context) async {
    try {
      // Sign out from Firebase
      await FirebaseAuth.instance.signOut();

      // Show success message
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Logged out successfully'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );

        // Navigate to home and clear all routes
        Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
      }
    } catch (e) {
      // Show error message if logout fails
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Logout failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF53E1E1), Color(0xFF1A237E)],
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50),
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.arrow_circle_left_outlined,
                      size: 40,
                      color: Colors.black,
                    ),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'MENU',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Student Menu List
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                children: [
                  _menuButton(context, "PROFILE"),
                  _menuButton(context, "DASHBOARD"),
                  _menuButton(context, "VIEW SCHEDULE"),
                  _menuButton(context, "MANAGE ATTENDANCE"),
                  _menuButton(context, "REPLACEMENT REQUEST"),
                  _menuButton(context, "NOTIFICATIONS"),
                  _menuButton(context, "LOGOUT"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menuButton(BuildContext context, String title) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFD1F2F9),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: const Icon(Icons.arrow_circle_right_outlined),
        onTap: () {
          switch (title) {
            case "PROFILE":
              Navigator.pushNamed(context, '/profile');
              break;
            case "DASHBOARD":
              Navigator.pushNamed(context, '/student_dashboard');
              break;
            case "VIEW SCHEDULE":
              Navigator.pushNamed(context, '/student_schedule');
              break;
            case "MANAGE ATTENDANCE":
              Navigator.pushNamed(context, '/student_attendance');
              break;
            case "REPLACEMENT REQUEST":
              Navigator.pushNamed(context, '/student_replacement');
              break;
            case "NOTIFICATIONS":
              Navigator.pushNamed(context, '/notification');
              break;
            case "LOGOUT":
              _showLogoutDialog(context);
              break;
          }
        },
      ),
    );
  }
}
