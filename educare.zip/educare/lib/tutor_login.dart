/*--------------------------------------------------
Author      : Noraziela Binti Jepsin
Updated by  : Noraziela Binti Jepsin
Tested by   :
Date        : 05 January 2026
Description : 
Tutor Login Screen - MAXIMUM SECURITY VERSION with DEBUG
- BLOCKS all unauthorized emails from logging in
- Double whitelist verification (before AND after authentication)
- Extensive debug logging to track issues

AUTHORIZED TUTORS:
- developer@educare.my (password: dev123)
- tutor_amir@educare.my (password: amir123)
- tutor_norlie@educare.my (password: norlie123)
- tutor_aainaa@educare.my (password: aainaa123)
- tutor_ziela@educare.my (password: ziela123)
--------------------------------------------------*/

import 'package:flutter/material.dart';
import 'tutor_menu.dart';

class TutorLoginScreen extends StatefulWidget {
  const TutorLoginScreen({super.key});

  @override
  State<TutorLoginScreen> createState() => _TutorLoginScreenState();
}

class _TutorLoginScreenState extends State<TutorLoginScreen> {
  bool _isObscured = true;
  bool _isLoading = false;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Hardcoded tutor email/password list
  final Map<String, String> allowedTutors = {
    "tutor_amir@educare.my": "amir123",
    "tutor_norlie@educare.my": "norlie123",
    "tutor_aainaa@educare.my": "aainaa123",
    "tutor_ziela@educare.my": "ziela123",
    "developer@educare.my": "dev123", // developer can also login as tutor
  };

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void loginUser() {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all fields")),
      );
      return;
    }

    setState(() => _isLoading = true);

    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() => _isLoading = false);

      if (allowedTutors.containsKey(email) &&
          allowedTutors[email] == password) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Login successful!")),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const TutorMenuScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Invalid email or password")),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF53E1E1), Color(0xFF90CAF9)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Icon(Icons.pets, size: 80, color: Color(0xFF1A237E)),
            const Text(
              'EduCare',
              style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A237E)),
            ),
            const SizedBox(height: 40),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(30),
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(50),
                      topRight: Radius.circular(50)),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const Text('TUTOR LOGIN',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2)),
                      const SizedBox(height: 30),
                      _buildInputLabel("Email"),
                      _buildTextField(_emailController, "Enter tutor email"),
                      const SizedBox(height: 20),
                      _buildInputLabel("Password"),
                      _buildTextField(
                          _passwordController, "Enter tutor password",
                          isPassword: true),
                      const SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: _isLoading ? null : loginUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFA7DED9),
                          minimumSize: const Size(200, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25)),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.black),
                                ),
                              )
                            : const Text('LOGIN',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputLabel(String text) => Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 8.0, left: 5),
          child:
              Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
      );

  Widget _buildTextField(TextEditingController controller, String hint,
          {bool isPassword = false}) =>
      TextField(
        controller: controller,
        obscureText: isPassword ? _isObscured : false,
        keyboardType:
            isPassword ? TextInputType.text : TextInputType.emailAddress,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                      _isObscured ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey),
                  onPressed: () => setState(() => _isObscured = !_isObscured),
                )
              : null,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none),
        ),
      );
}
